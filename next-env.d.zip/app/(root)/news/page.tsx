import Layout from "@/components/Layout";
import { AllNews } from "./_components/AllNews";

export default function NewsPage() {
  return (
    <Layout>
      <AllNews />
    </Layout>
  );
}
